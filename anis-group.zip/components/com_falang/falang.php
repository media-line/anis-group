<?php
/**
 *
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

echo "<div>";
echo "</div>";